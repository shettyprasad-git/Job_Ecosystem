export default function PracticePage() {
  return (
    <div>
      <h1 className="text-3xl font-bold">Practice Problems</h1>
      <p className="text-muted-foreground">Sharpen your coding skills.</p>
    </div>
  );
}
