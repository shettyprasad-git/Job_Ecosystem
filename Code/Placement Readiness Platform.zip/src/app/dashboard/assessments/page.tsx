export default function AssessmentsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold">Assessments</h1>
      <p className="text-muted-foreground">Test your knowledge with our assessments.</p>
    </div>
  );
}
