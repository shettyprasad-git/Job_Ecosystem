export default function ResourcesPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold">Resources</h1>
      <p className="text-muted-foreground">Find helpful resources for your preparation.</p>
    </div>
  );
}
