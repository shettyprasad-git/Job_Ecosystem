import { config } from 'dotenv';
config();

import '@/ai/flows/ai-audit-design-consistency.ts';